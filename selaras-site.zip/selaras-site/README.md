# SELARAS Layer Explorer

SELARAS (Spatially-Linked Ecological Layer Analysis and Rendering System) shows the seafloor, water column,
currents and biology of one ocean location in a linked 3D view. It runs entirely in the browser: `index.html`
is the whole app, with no server and nothing to install.

## Use it

Open the site link, or download `index.html` and double-click it (it also works offline).

The app opens with **Null Island**, an invented seamount filled with generated test numbers. It is not real data.
It is there to show what a complete location looks like.

## Load your own location

1. Click **Load a location** and choose the folder for one location.
2. The app checks the folder against the format and lists anything to fix.
3. Click **Open this location**.

Your files are read in your browser and are **not uploaded** anywhere. A loaded location is remembered in that
browser only.

## The locked data list

Every location uses the same six slots. File names, column names and units are fixed; only the rows change.

| # | Slot | File |
|---|------|------|
| 1 | Seafloor | `bathymetry.asc` (Esri ASCII grid, metres, negative below sea level) |
| 2 | Water-column physics | `profiles.csv` (temperature, salinity) |
| 3 | Water-column chemistry | `profiles.csv` (oxygen, chlorophyll, turbidity) |
| 4 | Currents | `currents.csv` |
| 5 | Biology | `biology.csv` |
| 6 | Stations and track | `stations.csv`, `track.csv` |

`dataset.json`, `bathymetry.asc` and `stations.csv` are required. Any other file can be missing, and its slot
then shows as empty. The **Input format** button in the app lists every column, and **Load a location** offers
an example folder to download.

## Keep restricted data out of this repository

This repository and its site can be opened by anyone who has the address. Do not add survey data that you are
not allowed to publish. Load it in the app from your own computer instead; it stays there.

## Rebuild after changing the code

The code is in `source/src`. To rebuild `index.html` (Python 3, no packages needed):

```
python3 source/tools/build.py --site . --only null_island_test
```

`--only` lists the folders in `source/datasets` to build into the page.
